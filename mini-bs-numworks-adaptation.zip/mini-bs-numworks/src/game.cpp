// ===================================================================
//  BRAWL MICROSTARS v2 — Shooter 2D type Brawl Stars pour NumWorks
//  App externe Epsilon (fichier .nwa apres compilation)
//
//  CONTROLES (clavier NumWorks) :
//    Fleches      : deplacer le brawler
//    OK / EXE     : attaquer (auto-visee sur l'ennemi le plus proche)
//    Shift        : Super (jauge chargee en touchant des ennemis)
//    X            : Gadget (2 utilisations par partie)
//    '-' (Minus)  : Hypercharge (niveau 11 requis, Super pleine)
//    + * /        : achats dans le menu BRAWLERS (upgrade/gadget/star)
//    Back         : quitter le match / menu
//
//  STYLE BRAWL STARS 2D :
//   - Barres de vie segmentees au-dessus des brawlers (+segment = 400 PV)
//   - Munitions affichees sous le joueur (3 barres orange comme BS)
//   - Anneau de Super violet autour du joueur quand charge
//   - Anneau Hypercharge magenta + trainee
//   - Ombres portees, contours noirs (style cartoon BS)
//   - Chiffres de degats flottants (jaune = allie, rouge = ennemi)
//   - Buissons BS (blobs verts arrondis qui masquent), murs pseudo-3D
//   - Zone empoisonnee violette qui avance par vagues (Survivant)
//   - Gemmes diamant, ballon avec ombre + cages de but dessinees
//   - Ecran de tremblement (screen shake) lors des supers/impacts
//   - Menus a boutons jaunes arrondis + cartes brawlers + vignettes
//
//  MODES : Ramasse-Gemmes 3v3 / Brawl Ball 3v3 / Survivant 6 joueurs
//  15 BRAWLERS, niveaux 1 a 11, gadgets, pouvoirs star, hypercharge.
// ===================================================================

#include "ion.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

// ------------------------- Ecran / rendu ---------------------------
#define SW 320
#define SH 222
#define TILE 14
#define MAPW 32
#define MAPH 24

static KDColor frameBuf[SW * SH];
static uint16_t seed = 12345;
static int rnd(int n) { seed = (seed * 25173 + 13849) & 0xFFFF; return (seed >> 4) % (n > 0 ? n : 1); }

static inline void px(int x, int y, KDColor c) {
  if (x >= 0 && x < SW && y >= 0 && y < SH) frameBuf[y * SW + x] = c;
}
static void fRect(int x, int y, int w, int h, KDColor c) {
  if (w < 0) { x += w; w = -w; } if (h < 0) { y += h; h = -h; }
  for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) px(i, j, c);
}
// rectangle arrondi (style boutons BS)
static void rRect(int x, int y, int w, int h, int r, KDColor c) {
  for (int j = 0; j < h; j++)
    for (int i = 0; i < w; i++) {
      int dx = (i < r) ? (r - i) : ((i >= w - r) ? (i - (w - r - 1)) : 0);
      int dy = (j < r) ? (r - j) : ((j >= h - r) ? (j - (h - r - 1)) : 0);
      if (dx * dx + dy * dy <= r * r) px(x + i, y + j, c);
    }
}
static void fCirc(int cx, int cy, int r, KDColor c) {
  for (int j = -r; j <= r; j++)
    for (int i = -r; i <= r; i++)
      if (i * i + j * j <= r * r) px(cx + i, cy + j, c);
}
// disque avec contour (style cartoon BS)
static void oCirc(int cx, int cy, int r, KDColor fill, KDColor outline) {
  for (int j = -r - 1; j <= r + 1; j++)
    for (int i = -r - 1; i <= r + 1; i++) {
      int d2 = i * i + j * j;
      if (d2 <= r * r) px(cx + i, cy + j, fill);
      else if (d2 <= (r + 1) * (r + 1)) px(cx + i, cy + j, outline);
    }
}
// disque degrade vertical (donne du volume au personnage)
static void shCirc(int cx, int cy, int r, KDColor top, KDColor bot, KDColor outline) {
  for (int j = -r - 1; j <= r + 1; j++)
    for (int i = -r - 1; i <= r + 1; i++) {
      int d2 = i * i + j * j;
      if (d2 <= r * r) {
        float t = (float)(j + r) / (2.0f * r);
        KDColor c;
        c = KDColor::RGB(
          (uint8_t)(top.red() + (bot.red() - top.red()) * t),
          (uint8_t)(top.green() + (bot.green() - top.green()) * t),
          (uint8_t)(top.blue() + (bot.blue() - top.blue()) * t));
        px(cx + i, cy + j, c);
      } else if (d2 <= (r + 1) * (r + 1)) px(cx + i, cy + j, outline);
    }
}
static void fRing(int cx, int cy, int r, KDColor c) {
  for (int a = 0; a < 360; a += 3)
    px(cx + (int)(r * cosf(a * 0.01745f)), cy + (int)(r * sinf(a * 0.01745f)), c);
}
// arc de cercle epais (jauges circulaires BS : munitions / super)
static void arc(int cx, int cy, int r, float a0, float a1, int thick, KDColor c) {
  for (int a = (int)(a0 * 180 / 3.14159f); a < (int)(a1 * 180 / 3.14159f); a++)
    for (int t = r - thick; t <= r; t++)
      px(cx + (int)(t * cosf(a * 0.01745f)), cy + (int)(t * sinf(a * 0.01745f)), c);
}
static void line(int x0, int y0, int x1, int y1, KDColor c) {
  int dx = abs(x1 - x0), dy = abs(y1 - y0);
  int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy;
  while (true) {
    px(x0, y0, c);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 > -dy) { err -= dy; x0 += sx; }
    if (e2 < dx) { err += dx; y0 += sy; }
  }
}
// ombre portee elliptique sous les objets
static void shadow(int cx, int cy, int rx, int ry) {
  for (int j = -ry; j <= ry; j++)
    for (int i = -rx; i <= rx; i++)
      if ((i * i * 100) / (rx * rx + 1) + (j * j * 100) / (ry * ry + 1) <= 100)
        px(cx + i, cy + j, KDColor::RGB24(0x0A1608));
}
static void blit() { Ion::Display::pushRect(KDRect(0, 0, SW, SH), frameBuf); }

// ------------------------- Palette BS-like --------------------------
#define C_BG     KDColor::RGB24(0x1B2A41)
#define C_PANEL  KDColor::RGB24(0x3B2A63)  // violet fonce BS menus
#define C_PANEL2 KDColor::RGB24(0x4A3785)
#define C_BTN    KDColor::RGB24(0xFFC928)  // jaune boutons BS
#define C_BTND   KDColor::RGB24(0xD9A400)
#define C_GRD    KDColor::RGB24(0x5AA02C)  // herbe claire
#define C_GRD2   KDColor::RGB24(0x4F9026)  // herbe foncee (damier BS)
#define C_GRD3   KDColor::RGB24(0x66B534)
#define C_WALL   KDColor::RGB24(0xB08050)
#define C_WALLD  KDColor::RGB24(0x7A5432)
#define C_WALLL  KDColor::RGB24(0xD0A070)
#define C_BUSH   KDColor::RGB24(0x3D7A20)
#define C_BUSH2  KDColor::RGB24(0x4F9A2E)
#define C_BLUE   KDColor::RGB24(0x2E9BFF)  // equipe bleue
#define C_BLUED  KDColor::RGB24(0x1E6FBF)
#define C_RED    KDColor::RGB24(0xFF3B3B)  // equipe rouge
#define C_REDD   KDColor::RGB24(0xBF2222)
#define C_WHT    KDColor::RGB24(0xFFFFFF)
#define C_BLK    KDColor::RGB24(0x101010)
#define C_YEL    KDColor::RGB24(0xFFC928)
#define C_ORG    KDColor::RGB24(0xFF8327)  // munitions BS
#define C_PUR    KDColor::RGB24(0xB44BFF)
#define C_MAG    KDColor::RGB24(0xFF2EA6)  // hypercharge magenta
#define C_CYN    KDColor::RGB24(0x35D4E8)  // gadgets BS
#define C_GRE    KDColor::RGB24(0x8A8A8A)
#define C_GEM    KDColor::RGB24(0x35D4E8)
#define C_GEMD   KDColor::RGB24(0x1B8FA8)
#define C_BALL   KDColor::RGB24(0xF2F2F2)
#define C_POISON KDColor::RGB24(0x7B2FA0)
#define C_POIS2  KDColor::RGB24(0x5A1F78)
#define C_TROPH  KDColor::RGB24(0xFFC928)
#define C_GREEN   KDColor::RGB24(0x3DDC55)

// ------------------------- Definitions brawlers --------------------
enum AtkType { ATK_SHOT, ATK_SPREAD, ATK_LOB };
enum SuperType { SUP_BURST, SUP_DASH, SUP_HEAL, SUP_BARRAGE, SUP_MEGASHOT };
enum GadType { GAD_HEAL, GAD_SPEED, GAD_AMMO, GAD_BLAST };
enum StarType { STAR_DMG, STAR_HP, STAR_SPEED, STAR_REGEN };

struct BrawlerDef {
  const char *name;
  int baseHP, baseDmg, range;
  int reloadMs;
  float projSpeed;
  int projCount, spreadDeg;
  AtkType atk;
  SuperType sup;
  GadType gad;
  StarType star;
  int superCost;
  uint32_t colTop, colBot;   // couleurs RGB24 du corps (degrade)
  uint8_t projShape;         // 0 balle, 1 eclat, 2 fusee, 3 grenade
};

static const BrawlerDef BRAWLERS[15] = {
  // nom        HP    dmg   range reload prSpd nP spread atk           super         gadget    star        cost  top/bottom    shape
  {"Shelly",   5600, 1280, 170, 1500, 340, 3, 24, ATK_SPREAD, SUP_BURST,    GAD_SPEED, STAR_DMG, 100, 0x8A4BE0, 0x5C2BA0, 0},
  {"Nita",     5400, 1320, 160, 1400, 330, 1,  0, ATK_SHOT,   SUP_BURST,    GAD_HEAL,  STAR_HP,  100, 0xC98A3B, 0x8A5C22, 1},
  {"Colt",     4000,  940, 240, 1600, 420, 6,  8, ATK_SHOT,   SUP_MEGASHOT, GAD_AMMO,  STAR_DMG, 100, 0x3B9AC9, 0x22628A, 1},
  {"Bull",     6600, 1750, 100, 1900, 300, 5, 30, ATK_SPREAD, SUP_DASH,     GAD_BLAST, STAR_HP,  100, 0xC9973B, 0x8A6622, 0},
  {"Jessie",   4600, 1180, 210, 1700, 300, 1,  0, ATK_SHOT,   SUP_BARRAGE,  GAD_AMMO,  STAR_REGEN,100,0xA03BA0, 0x701F70, 2},
  {"Brock",    3800, 1620, 280, 2000, 360, 1,  0, ATK_LOB,    SUP_MEGASHOT, GAD_SPEED, STAR_DMG, 100, 0xC93B3B, 0x8A2222, 2},
  {"Dynamike",4000, 1330, 230, 1800, 280, 2, 12, ATK_LOB,     SUP_BARRAGE,  GAD_BLAST, STAR_DMG, 100, 0xE0B03B, 0xA07822, 3},
  {"Bo",       5000, 1200, 250, 1800, 310, 3,  9, ATK_LOB,    SUP_BARRAGE,  GAD_SPEED, STAR_REGEN,100,0x3B7AC9, 0x224F8A, 2},
  {"Tick",     3000, 1120, 260, 1500, 260, 1,  0, ATK_LOB,    SUP_BARRAGE,  GAD_BLAST, STAR_REGEN,100,0x8AC93B, 0x5C8A22, 3},
  {"8-Bit",    5800, 1350, 260, 2000, 330, 1,  0, ATK_SHOT,   SUP_MEGASHOT, GAD_AMMO,  STAR_DMG, 100, 0xC9A03B, 0x8A6E22, 1},
  {"Rico",     4200, 1010, 260, 1500, 400, 5,  6, ATK_SHOT,   SUP_MEGASHOT, GAD_SPEED, STAR_DMG, 100, 0x3BC9B0, 0x228A78, 1},
  {"Darryl",   6300, 1460, 130, 1400, 380, 2, 14, ATK_SPREAD, SUP_DASH,     GAD_BLAST, STAR_HP,  100, 0xC96B3B, 0x8A4822, 0},
  {"Penny",    4600, 1290, 230, 1700, 340, 1,  0, ATK_SHOT,   SUP_BARRAGE,  GAD_HEAL,  STAR_REGEN,100,0xE07B3B, 0xA05222, 0},
  {"Carl",     5500, 1250, 190, 1200, 320, 1,  0, ATK_SHOT,   SUP_DASH,     GAD_SPEED, STAR_HP,  100, 0x7B9BC9, 0x50688A, 3},
  {"Poco",     5600, 1100, 200, 1400, 300, 3, 16, ATK_SPREAD, SUP_HEAL,     GAD_HEAL,  STAR_REGEN,100,0xB03BE0, 0x7822A0, 1},
};

// ------------------------- Compte / progression --------------------
struct BrawlerAccount { int level, trophies; bool gadget, starPower, hyper; };
struct Account { BrawlerAccount b[15]; int coins; } acc;

static int upgradeCost(int lvl) { return 20 + lvl * 30; }
static float lvlMul(int lvl) { return 1.0f + (lvl - 1) * 0.05f; }

static void initAcc() {
  acc.coins = 150;
  for (int i = 0; i < 15; i++) {
    acc.b[i].level = (i == 0) ? 3 : 1;
    acc.b[i].trophies = 0;
    acc.b[i].gadget = (i == 0);
    acc.b[i].starPower = (i == 0);
    acc.b[i].hyper = false;
  }
}

// ------------------------- Monde ------------------------------------
enum GameMode { MODE_GEM = 0, MODE_BALL = 1, MODE_SOLO = 2 };
static const char *MODE_NAMES[3] = {"RAMASSE-GEMMES", "BRAWL BALL", "SURVIVANT"};

static uint8_t tileMap[MAPW][MAPH];

// ------------------------- Entites ----------------------------------
#define MAX_ENT 8
#define MAX_PROJ 64
#define MAX_POP 16

struct Ent {
  int brawlerIdx, accIdx, team;
  float x, y, hp, maxHP;
  float ammo, superCharge;
  int gadgetUses;
  bool isHuman, alive;
  int respawnT, respawnTotal;
  float regenT;
  float speedBuffT, hyperT, dashT, aimAng, faceAng;
  int dashDx, dashDy;
  int gems, goals;
  bool hasBall;
  int aiThinkT, aiWx, aiWy;
  int walkT;              // animation de marche
  int lastHitT;           // flash blanc quand touche
  bool drawDone;          // tri d'affichage par Y
};

static Ent ents[MAX_ENT]; static int entCount = 0;
static int humanIdx = -1;

struct Proj {
  bool active, lob, fromSuper;
  float x, y, vx, vy, dmg, travelled, range;
  int team, owner, radius, shape, spin;
};
static Proj projs[MAX_PROJ];

struct Pop { bool active; float x, y; int life, val; bool big; };
static Pop pops[MAX_POP];

struct Gem { bool active; float x, y; };
static Gem gems[10];

static float ballX, ballY, ballVX, ballVY;
static int mode, gemCountdown, teamGems[3];
static int soloShrink, poisonWaveT, matchTimeMs, respawnMs = 3000;
static int shakeT = 0, shakeMag = 0;
static int animT = 0;

static void addPop(float x, float y, int val, bool big) {
  for (int i = 0; i < MAX_POP; i++)
    if (!pops[i].active) {
      pops[i].active = true; pops[i].x = x; pops[i].y = y;
      pops[i].life = 900; pops[i].val = val; pops[i].big = big;
      return;
    }
}

// ------------------------- Utilitaires monde ------------------------
static bool solidAt(float x, float y) {
  int tx = (int)(x / TILE), ty = (int)(y / TILE);
  if (tx < 0 || ty < 0 || tx >= MAPW || ty >= MAPH) return true;
  return tileMap[tx][ty] == 1;
}
static bool inBush(float x, float y) {
  int tx = (int)(x / TILE), ty = (int)(y / TILE);
  if (tx < 0 || ty < 0 || tx >= MAPW || ty >= MAPH) return false;
  return tileMap[tx][ty] == 2;
}
static void moveEnt(Ent &e, float dx, float dy) {
  if (solidAt(e.x + dx, e.y)) dx = 0;
  if (solidAt(e.x, e.y + dy)) dy = 0;
  e.x += dx; e.y += dy;
  e.x = fmaxf(8, fminf(MAPW * TILE - 8, e.x));
  e.y = fmaxf(8, fminf(MAPH * TILE - 8, e.y));
  if (dx || dy) { e.faceAng = atan2f(dy, dx); e.walkT += (int)(fabsf(dx) + fabsf(dy)); }
}

// ------------------------- Generation carte --------------------------
static void genMap() {
  for (int x = 0; x < MAPW; x++)
    for (int y = 0; y < MAPH; y++) {
      tileMap[x][y] = 0;
      if (x == 0 || y == 0 || x == MAPW - 1 || y == MAPH - 1) tileMap[x][y] = 1;
    }
  for (int t = 0; t < 90; t++) {
    int x = 1 + rnd(MAPW / 2), y = 1 + rnd(MAPH - 2);
    int v = rnd(10) < 4 ? 2 : 1;
    if (x < 5 || abs((int)(y - MAPH / 2)) < 2) continue;
    tileMap[x][y] = v;
    tileMap[MAPW - 1 - x][MAPH - 1 - y] = v;
  }
  if (mode == MODE_BALL)
    for (int x = 1; x < MAPW - 1; x++)
      for (int y = MAPH / 2 - 1; y <= MAPH / 2 + 1; y++) tileMap[x][y] = 0;
}

// ------------------------- Spawn des equipes -------------------------
static void addEnt(int bIdx, int accIdx, int team, float x, float y, bool human) {
  Ent &e = ents[entCount++];
  const BrawlerDef &d = BRAWLERS[bIdx];
  int lvl = 1; bool star = false, gad = false;
  if (accIdx >= 0) {
    lvl = acc.b[accIdx].level; star = acc.b[accIdx].starPower; gad = acc.b[accIdx].gadget;
  } else { lvl = 1 + rnd(4); star = rnd(2); gad = true; }
  float mul = lvlMul(lvl);
  if (star && d.star == STAR_HP) mul *= 1.05f;
  e.brawlerIdx = bIdx; e.accIdx = accIdx; e.team = team;
  e.x = x; e.y = y;
  e.maxHP = d.baseHP * mul; e.hp = e.maxHP;
  e.ammo = 3; e.superCharge = 0;
  e.gadgetUses = (accIdx >= 0 && !gad) ? 0 : 2;
  e.isHuman = human; e.alive = true; e.respawnT = 0; e.respawnTotal = respawnMs;
  e.regenT = 0; e.speedBuffT = e.hyperT = e.dashT = 0;
  e.aimAng = e.faceAng = (team == 0) ? 0 : 3.14159f;
  e.gems = 0; e.hasBall = false; e.goals = 0;
  e.aiThinkT = rnd(500); e.aiWx = x; e.aiWy = y;
  e.walkT = 0; e.lastHitT = 0; e.drawDone = false;
}

static void setupMatch(int selMode, int myBrawler) {
  mode = selMode; entCount = 0; humanIdx = -1;
  for (int i = 0; i < MAX_PROJ; i++) projs[i].active = false;
  for (int i = 0; i < MAX_POP; i++) pops[i].active = false;
  for (int i = 0; i < 10; i++) gems[i].active = false;
  genMap();
  teamGems[0] = teamGems[1] = 0; gemCountdown = -1;
  matchTimeMs = 0; shakeT = 0; poisonWaveT = 0;

  if (mode == MODE_SOLO) {
    static const float pos[6][2] = {{40,40},{MAPW*TILE-40,40},{40,MAPH*TILE-40},{MAPW*TILE-40,MAPH*TILE-40},{MAPW*TILE/2,30},{MAPW*TILE/2,MAPH*TILE-30}};
    for (int i = 0; i < 6; i++) {
      int bIdx = (i == 0) ? myBrawler : rnd(15);
      int accIdx = (i == 0) ? myBrawler : -1;
      addEnt(bIdx, accIdx, i, pos[i][0], pos[i][1], i == 0);
      if (i == 0) humanIdx = 0;
    }
    soloShrink = (MAPW + MAPH) * TILE / 2 + 200;
    poisonWaveT = 25000;
  } else {
    addEnt(myBrawler, myBrawler, 0, 40, MAPH * TILE / 2, true); humanIdx = 0;
    int pool[15]; for (int i = 0; i < 15; i++) pool[i] = i;
    for (int i = 14; i > 0; i--) { int j = rnd(i + 1); int t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
    int p = 0;
    if (pool[p] == myBrawler) p++;
    addEnt(pool[p++], -1, 0, 40, MAPH * TILE / 2 - 70, false);
    addEnt(pool[p++], -1, 0, 40, MAPH * TILE / 2 + 70, false);
    addEnt(pool[p++], -1, 1, MAPW * TILE - 40, MAPH * TILE / 2, false);
    addEnt(pool[p++], -1, 1, MAPW * TILE - 40, MAPH * TILE / 2 - 70, false);
    addEnt(pool[p++], -1, 1, MAPW * TILE - 40, MAPH * TILE / 2 + 70, false);
    if (mode == MODE_GEM)
      for (int i = 0; i < 6; i++) {
        gems[i].active = true;
        gems[i].x = MAPW * TILE / 2 + (rnd(3) - 1) * 30;
        gems[i].y = MAPH * TILE / 2 + (rnd(3) - 1) * 30;
      }
    else if (mode == MODE_BALL) {
      ballX = MAPW * TILE / 2; ballY = MAPH * TILE / 2; ballVX = ballVY = 0;
    }
  }
}

// ------------------------- Projectiles ------------------------------
static void fireProj(Ent &e, float ang, bool isSuper, float dmgMul, float spdMul, float rangeMul) {
  const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
  for (int i = 0; i < MAX_PROJ; i++) {
    if (projs[i].active) continue;
    Proj &p = projs[i];
    p.active = true; p.lob = (d.atk == ATK_LOB); p.fromSuper = isSuper;
    p.x = e.x; p.y = e.y;
    float sp = d.projSpeed * spdMul;
    p.vx = cosf(ang) * sp; p.vy = sinf(ang) * sp;
    p.dmg = d.baseDmg * dmgMul;
    p.range = d.range * rangeMul;
    p.travelled = 0; p.team = e.team; p.owner = (&e - ents);
    p.radius = isSuper ? 4 : 2;
    p.shape = d.projShape; p.spin = 0;
    return;
  }
}

static void doAttack(Ent &e, float ang) {
  const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
  if (e.ammo < 1) return;
  e.aimAng = ang;
  float mul = lvlMul(e.accIdx >= 0 ? acc.b[e.accIdx].level : 1);
  if (e.hyperT > 0) mul *= 1.25f;
  if (e.accIdx >= 0 && acc.b[e.accIdx].starPower && d.star == STAR_DMG) mul *= 1.1f;
  int n = d.projCount, spread = d.spreadDeg;
  for (int i = 0; i < n; i++) {
    float a = ang + ((n > 1) ? (spread * 0.01745f * (i - (n - 1) / 2.0f)) : 0);
    fireProj(e, a, false, mul, 1.0f, 1.0f);
  }
  e.ammo -= 1; e.regenT = 0;
}

static void doSuper(Ent &e, float ang) {
  const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
  if (e.superCharge < d.superCost) return;
  e.superCharge = 0; e.aimAng = ang;
  float mul = lvlMul(e.accIdx >= 0 ? acc.b[e.accIdx].level : 1);
  if (e.hyperT > 0) mul *= 1.25f;
  shakeT = 200; shakeMag = 3;   // impact visuel du super
  switch (d.sup) {
    case SUP_BURST: {
      for (int i = 0; i < entCount; i++)
        if (ents[i].alive && ents[i].team != e.team) {
          float dx = ents[i].x - e.x, dy = ents[i].y - e.y;
          if (dx * dx + dy * dy < 80 * 80) { ents[i].hp -= d.baseDmg * 1.6f * mul; ents[i].regenT = 0; ents[i].lastHitT = 150; }
        }
      for (int a = 0; a < 16; a++) fireProj(e, a * 0.3927f, true, mul * 0.6f, 1.2f, 0.5f);
      break;
    }
    case SUP_DASH: { e.dashT = 0.35f; e.dashDx = (int)(cosf(ang) * 320); e.dashDy = (int)(sinf(ang) * 320); break; }
    case SUP_HEAL: {
      for (int i = 0; i < entCount; i++)
        if (ents[i].alive && ents[i].team == e.team) {
          float before = ents[i].hp;
          ents[i].hp = fminf(ents[i].maxHP, ents[i].hp + ents[i].maxHP * 0.4f);
          if (ents[i].hp > before) addPop(ents[i].x, ents[i].y - 12, (int)(ents[i].hp - before), false);
        }
      break;
    }
    case SUP_BARRAGE: {
      for (int i = 0; i < 8; i++) fireProj(e, ang + (rnd(30) - 15) * 0.01745f, true, mul, 1.0f, 1.3f);
      break;
    }
    case SUP_MEGASHOT: { fireProj(e, ang, true, mul * 2.5f, 1.3f, 1.6f); break; }
  }
}

static void doGadget(Ent &e) {
  const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
  if (e.gadgetUses <= 0) return;
  e.gadgetUses--;
  switch (d.gad) {
    case GAD_HEAL: e.hp = fminf(e.maxHP, e.hp + e.maxHP * 0.25f); addPop(e.x, e.y - 12, (int)(e.maxHP * 0.25f), false); break;
    case GAD_SPEED: e.speedBuffT = 4.0f; break;
    case GAD_AMMO: e.ammo = 3; break;
    case GAD_BLAST:
      shakeT = 150; shakeMag = 2;
      for (int i = 0; i < entCount; i++)
        if (ents[i].alive && ents[i].team != e.team) {
          float dx = ents[i].x - e.x, dy = ents[i].y - e.y;
          if (dx * dx + dy * dy < 90 * 90) { ents[i].hp -= 900; ents[i].regenT = 0; ents[i].lastHitT = 150; addPop(ents[i].x, ents[i].y - 12, 900, false); }
        }
      break;
  }
}

static void doHypercharge(Ent &e) {
  if (e.accIdx < 0 || !acc.b[e.accIdx].hyper) return;
  const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
  if (e.superCharge < d.superCost) return;
  e.superCharge = 0;
  e.hyperT = 8.0f; e.speedBuffT = 8.0f;
  shakeT = 300; shakeMag = 4;
}

// ------------------------- Entree clavier ----------------------------
static bool keyOK, keyBack, prevOK, prevShift, prevX, prevMinus, prevBack;
static bool kUp, kDown, kLeft, kRight, kShift, kX, kMinus;

static void pollKeys() {
  Ion::Keyboard::State st = Ion::Keyboard::getState();
  using K = Ion::Keyboard::Key;
  kUp = st.keyDown(K::Up); kDown = st.keyDown(K::Down);
  kLeft = st.keyDown(K::Left); kRight = st.keyDown(K::Right);
  keyOK = st.keyDown(K::OK) || st.keyDown(K::EXE);
  kShift = st.keyDown(K::Shift); kX = st.keyDown(K::X);
  kMinus = st.keyDown(K::Minus); keyBack = st.keyDown(K::Back);
}

// ------------------------- IA ---------------------------------------
static float nearestEnemyDist(Ent &e, Ent **out) {
  float best = 1e9; *out = nullptr;
  for (int i = 0; i < entCount; i++) {
    Ent &o = ents[i];
    if (!o.alive || o.team == e.team) continue;
    if (inBush(o.x, o.y) && e.team == o.team) continue;
    float dx = o.x - e.x, dy = o.y - e.y, d2 = dx * dx + dy * dy;
    if (d2 < best) { best = d2; *out = &o; }
  }
  return sqrtf(best);
}

static void updateAI(Ent &e, float dt) {
  e.aiThinkT -= (int)(dt * 1000);
  const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
  if (e.aiThinkT <= 0) {
    e.aiThinkT = 300 + rnd(400);
    float tx = e.x, ty = e.y;
    if (mode == MODE_GEM) {
      for (int i = 0; i < 10; i++)
        if (gems[i].active) { tx = gems[i].x; ty = gems[i].y; break; }
    } else if (mode == MODE_BALL && !e.hasBall && ballVX == 0 && ballVY == 0) {
      tx = ballX; ty = ballY;
    }
    Ent *tgt = nullptr;
    float ed = nearestEnemyDist(e, &tgt);
    if (tgt && ed < d.range * 1.1f) { tx = tgt->x; ty = tgt->y; }
    if (mode == MODE_BALL && e.hasBall) { tx = (e.team == 0) ? MAPW * TILE - 20 : 20; ty = MAPH * TILE / 2; }
    if (mode == MODE_SOLO && e.hp < e.maxHP * 0.3f && tgt && ed < 200) { tx = e.x - (tgt->x - e.x); ty = e.y - (tgt->y - e.y); }
    e.aiWx = tx; e.aiWy = ty;
    if (tgt && ed < d.range * 0.95f && e.ammo >= 1)
      doAttack(e, atan2f(tgt->y - e.y, tgt->x - e.x) + (rnd(10) - 5) * 0.01745f);
    if (e.superCharge >= d.superCost && tgt && ed < d.range)
      doSuper(e, atan2f(tgt->y - e.y, tgt->x - e.x));
    if (e.gadgetUses > 0 && e.hp < e.maxHP * 0.35f) doGadget(e);
  }
  float dx = e.aiWx - e.x, dy = e.aiWy - e.y;
  float len = sqrtf(dx * dx + dy * dy);
  if (len > 10) { dx /= len; dy /= len; moveEnt(e, dx * 100 * dt, dy * 100 * dt); }
}

// ------------------------- Mise a jour match -------------------------
static int matchResult = -2;

static void damageEnt(Ent &e, float dmg, Ent &src) {
  e.hp -= dmg; e.regenT = 0; e.lastHitT = 150;
  const BrawlerDef &d = BRAWLERS[src.brawlerIdx];
  src.superCharge = fminf(100, src.superCharge + (src.hyperT > 0 ? 3.5f : 2.0f));
  addPop(e.x + rnd(8) - 4, e.y - 12, (int)dmg, src.isHuman);
}

static void updateMatch(float dt) {
  matchTimeMs += (int)(dt * 1000);
  animT += (int)(dt * 1000);
  if (shakeT > 0) shakeT -= (int)(dt * 1000);
  bool solo = (mode == MODE_SOLO);

  // degats flottants
  for (int i = 0; i < MAX_POP; i++)
    if (pops[i].active) { pops[i].life -= (int)(dt * 1000); pops[i].y -= dt * 22; if (pops[i].life <= 0) pops[i].active = false; }

  Ent &me = ents[humanIdx];
  pollKeys();
  if (keyBack) { matchResult = solo ? 0 : -1; return; }
  if (me.alive) {
    float spd = 110.0f;
    if (me.speedBuffT > 0) spd *= 1.3f;
    if (me.hyperT > 0) spd *= 1.15f;
    const BrawlerDef &d = BRAWLERS[me.brawlerIdx];
    if (me.accIdx >= 0 && acc.b[me.accIdx].starPower && d.star == STAR_SPEED) spd *= 1.1f;
    float dx = (kRight ? 1 : 0) - (kLeft ? 1 : 0);
    float dy = (kDown ? 1 : 0) - (kUp ? 1 : 0);
    if (dx || dy) { float l = sqrtf(dx * dx + dy * dy); moveEnt(me, dx / l * spd * dt, dy / l * spd * dt); }
    if (keyOK && !prevOK) {
      Ent *tgt = nullptr; nearestEnemyDist(me, &tgt);
      float ang = tgt ? atan2f(tgt->y - me.y, tgt->x - me.x) : (dy || dx ? atan2f(dy, dx) : me.faceAng);
      doAttack(me, ang);
    }
    if (kShift && !prevShift) {
      Ent *tgt = nullptr; nearestEnemyDist(me, &tgt);
      float ang = tgt ? atan2f(tgt->y - me.y, tgt->x - me.x) : me.aimAng;
      doSuper(me, ang);
    }
    if (kX && !prevX) doGadget(me);
    if (kMinus && !prevMinus) doHypercharge(me);
  }
  prevOK = keyOK; prevShift = kShift; prevX = kX; prevMinus = kMinus;

  for (int i = 0; i < entCount; i++) {
    Ent &e = ents[i];
    if (!e.alive) {
      e.respawnT -= (int)(dt * 1000);
      if (e.respawnT <= 0 && !solo) {
        e.alive = true; e.hp = e.maxHP; e.ammo = 3;
        e.x = (e.team == 0) ? 40 : MAPW * TILE - 40;
        e.y = MAPH * TILE / 2 + (rnd(3) - 1) * 60;
      }
      continue;
    }
    if (!e.isHuman) updateAI(e, dt);
    if (e.speedBuffT > 0) e.speedBuffT -= dt;
    if (e.hyperT > 0) e.hyperT -= dt;
    if (e.lastHitT > 0) e.lastHitT -= (int)(dt * 1000);
    if (e.dashT > 0) {
      e.dashT -= dt;
      moveEnt(e, e.dashDx * dt, e.dashDy * dt);
      for (int j = 0; j < entCount; j++)
        if (ents[j].alive && ents[j].team != e.team) {
          float ddx = ents[j].x - e.x, ddy = ents[j].y - e.y;
          if (ddx * ddx + ddy * ddy < 20 * 20) damageEnt(ents[j], 2200, e);
        }
    }
    const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
    e.ammo = fminf(3, e.ammo + dt * 1000.0f / d.reloadMs);
    e.regenT += dt;
    float regenDelay = 4.0f;
    if (e.accIdx >= 0 && acc.b[e.accIdx].starPower && d.star == STAR_REGEN) regenDelay = 2.0f;
    if (e.regenT > regenDelay) e.hp = fminf(e.maxHP, e.hp + e.maxHP * 0.12f * dt);
    if (e.hyperT > 0) e.superCharge = fminf(100, e.superCharge + 6 * dt);
    if (e.hp <= 0) {
      e.alive = false; e.respawnT = respawnMs;
      if (e.gems > 0)
        for (int g = 0; g < 10 && e.gems > 0; g++)
          if (!gems[g].active) { gems[g].active = true; gems[g].x = e.x + rnd(20) - 10; gems[g].y = e.y + rnd(20) - 10; e.gems--; }
      if (e.hasBall) { e.hasBall = false; ballX = e.x; ballY = e.y; }
      shakeT = 200; shakeMag = 3;
      if (solo && e.isHuman) matchResult = -1;
    }
  }

  for (int i = 0; i < MAX_PROJ; i++) {
    Proj &p = projs[i];
    if (!p.active) continue;
    p.spin += 30;
    float nx = p.x + p.vx * dt, ny = p.y + p.vy * dt;
    p.travelled += sqrtf((nx - p.x) * (nx - p.x) + (ny - p.y) * (ny - p.y));
    p.x = nx; p.y = ny;
    if (p.travelled > p.range) { p.active = false; continue; }
    if (!p.lob && solidAt(p.x, p.y)) { p.active = false; continue; }
    if (p.lob && p.travelled > p.range * 0.6f && solidAt(p.x, p.y)) { p.active = false; continue; }
    for (int j = 0; j < entCount; j++) {
      Ent &t = ents[j];
      if (!t.alive || t.team == p.team) continue;
      float ddx = t.x - p.x, ddy = t.y - p.y;
      if (ddx * ddx + ddy * ddy < (p.radius + 7) * (p.radius + 7)) {
        damageEnt(t, p.dmg, ents[p.owner]);
        p.active = false; break;
      }
    }
  }

  if (mode == MODE_GEM) {
    teamGems[0] = teamGems[1] = 0;
    for (int i = 0; i < entCount; i++) if (ents[i].alive) teamGems[ents[i].team] += ents[i].gems;
    for (int g = 0; g < 10; g++) {
      if (!gems[g].active) continue;
      for (int i = 0; i < entCount; i++)
        if (ents[i].alive && fabsf(ents[i].x - gems[g].x) < 12 && fabsf(ents[i].y - gems[g].y) < 12) {
          gems[g].active = false; ents[i].gems++; break;
        }
      int actives = 0;
      for (int q = 0; q < 10; q++) actives += gems[q].active;
      if (actives == 0 && rnd(300) < 6) {
        gems[g].active = true;
        gems[g].x = MAPW * TILE / 2 + (rnd(3) - 1) * 40;
        gems[g].y = MAPH * TILE / 2 + (rnd(3) - 1) * 40;
      }
    }
    if (teamGems[0] >= 10 || teamGems[1] >= 10) {
      if (gemCountdown < 0) gemCountdown = 15000;
      gemCountdown -= (int)(dt * 1000);
      if (gemCountdown <= 0) matchResult = (teamGems[0] >= 10) ? 1 : -1;
    } else gemCountdown = -1;
  }

  if (mode == MODE_BALL) {
    bool carried = false;
    for (int i = 0; i < entCount; i++) if (ents[i].alive && ents[i].hasBall) carried = true;
    if (!carried) {
      for (int i = 0; i < entCount; i++) {
        Ent &e = ents[i];
        if (!e.alive || e.hasBall) continue;
        if (fabsf(e.x - ballX) < 12 && fabsf(e.y - ballY) < 12) { e.hasBall = true; break; }
      }
      if (!carried) {
        ballX += ballVX * dt; ballY += ballVY * dt;
        ballVX *= 0.95f; ballVY *= 0.95f;
        if (solidAt(ballX, ballY)) { ballX -= ballVX * dt * 2; ballY -= ballVY * dt * 2; ballVX = ballVY = 0; }
      }
    } else {
      for (int i = 0; i < entCount; i++)
        if (ents[i].alive && ents[i].hasBall) {
          ballX = ents[i].x; ballY = ents[i].y;
          if ((ents[i].team == 0 && ballX > MAPW * TILE - 26) ||
              (ents[i].team == 1 && ballX < 26)) {
            ents[i].goals++; ents[i].hasBall = false;
            ballX = MAPW * TILE / 2; ballY = MAPH * TILE / 2; ballVX = ballVY = 0;
            shakeT = 400; shakeMag = 5;
          }
        }
    }
    int g0 = 0, g1 = 0;
    for (int i = 0; i < entCount; i++) {
      if (ents[i].team == 0) g0 = fmaxf(g0, ents[i].goals); else g1 = fmaxf(g1, ents[i].goals);
    }
    if (g0 >= 2) matchResult = 1;
    if (g1 >= 2) matchResult = -1;
  }

  if (solo) {
    poisonWaveT -= (int)(dt * 1000);
    if (poisonWaveT <= 0) { poisonWaveT = 4000; soloShrink -= 60; }
    int cx = MAPW * TILE / 2, cy = MAPH * TILE / 2;
    for (int i = 0; i < entCount; i++) {
      Ent &e = ents[i];
      if (!e.alive) continue;
      int ddx = e.x - cx, ddy = e.y - cy;
      if (ddx * ddx + ddy * ddy > soloShrink * soloShrink) { e.hp -= 700 * dt; e.regenT = 0; }
    }
    int aliveTeams = 0;
    for (int i = 0; i < entCount; i++) if (ents[i].alive) aliveTeams++;
    if (aliveTeams == 1 && ents[humanIdx].alive) matchResult = 1;
  }

  if (matchTimeMs > 150000) matchResult = solo ? (ents[humanIdx].alive ? 1 : -1) : 0;
}

// ------------------------- Polices / texte ---------------------------
static const uint8_t FONT5[10][5] = {
  {0x0E,0x11,0x11,0x11,0x0E},{0x04,0x0C,0x04,0x04,0x0E},{0x0E,0x01,0x0E,0x10,0x0E},
  {0x0E,0x01,0x06,0x01,0x0E},{0x11,0x11,0x0E,0x01,0x01},{0x0E,0x10,0x0E,0x01,0x0E},
  {0x0E,0x10,0x0E,0x11,0x0E},{0x0E,0x01,0x02,0x04,0x04},{0x0E,0x11,0x0E,0x11,0x0E},
  {0x0E,0x11,0x0E,0x01,0x0E},
};
static const uint8_t FONTA[26][5] = {
  {0x0E,0x11,0x1F,0x11,0x11},{0x1E,0x11,0x1E,0x11,0x1E},{0x0F,0x10,0x10,0x10,0x0F},
  {0x1E,0x11,0x11,0x11,0x1E},{0x1F,0x10,0x1E,0x10,0x1F},{0x1F,0x10,0x1E,0x10,0x10},
  {0x0F,0x10,0x13,0x11,0x0F},{0x11,0x11,0x1F,0x11,0x11},{0x0E,0x04,0x04,0x04,0x0E},
  {0x07,0x02,0x02,0x02,0x1C},{0x11,0x12,0x1C,0x12,0x11},{0x10,0x10,0x10,0x10,0x1F},
  {0x11,0x1B,0x15,0x11,0x11},{0x11,0x19,0x15,0x13,0x11},{0x0E,0x11,0x11,0x11,0x0E},
  {0x1E,0x11,0x1E,0x10,0x10},{0x0E,0x11,0x15,0x12,0x0D},{0x1E,0x11,0x1E,0x12,0x11},
  {0x0F,0x10,0x0E,0x01,0x1E},{0x1F,0x04,0x04,0x04,0x04},{0x11,0x11,0x11,0x11,0x0E},
  {0x11,0x11,0x11,0x0A,0x04},{0x11,0x11,0x15,0x1B,0x11},{0x11,0x0A,0x04,0x0A,0x11},
  {0x11,0x11,0x0F,0x01,0x0E},{0x1F,0x01,0x0E,0x10,0x1F},
};

static void drawDigit(int x, int y, int d, KDColor c) {
  for (int r = 0; r < 5; r++) {
    uint8_t row = FONT5[d][r];
    for (int col = 0; col < 4; col++)
      if (row & (0x10 >> col)) { px(x + col, y + r, c); px(x + col + 1, y + r + 1, C_BLK); }
  }
}
static void drawNum(int x, int y, int v, KDColor c) {
  if (v < 0) { fRect(x, y + 2, 3, 1, c); drawNum(x + 5, y, -v, c); return; }
  char buf[8]; int n = 0;
  do { buf[n++] = '0' + v % 10; v /= 10; } while (v);
  for (int i = n - 1; i >= 0; i--) { drawDigit(x, y, buf[i] - '0', c); x += 6; }
}
static void drawText(int x, int y, const char *s, KDColor c) {
  while (*s) {
    char ch = *s++;
    if (ch == ' ') { x += 5; continue; }
    if (ch == '-') { fRect(x, y + 2, 4, 1, c); x += 5; continue; }
    if (ch == '!') { fRect(x, y, 1, 5, c); x += 4; continue; }
    if (ch == ':') { fRect(x, y, 1, 1, c); fRect(x, y + 3, 1, 1, c); x += 4; continue; }
    if (ch == '.') { fRect(x, y + 4, 1, 1, c); x += 4; continue; }
    if (ch >= 'A' && ch <= 'Z') {
      for (int r = 0; r < 5; r++) {
        uint8_t row = FONTA[ch - 'A'][r];
        for (int col = 0; col < 5; col++)
          if (row & (0x10 >> col)) { px(x + col, y + r, c); px(x + col + 1, y + r + 1, C_BLK); }
      }
    } else if (ch >= '0' && ch <= '9') drawDigit(x, y, ch - '0', c);
    x += 6;
  }
}
static int textW(const char *s) { int w = 0; for (const char *p = s; *p; p++) w += (*p == ' ') ? 5 : 6; return w; }
static void drawTextC(int y, const char *s, KDColor c) { drawText((SW - textW(s)) / 2, y, s, c); }
// texte avec contour jaune sur bandeau (style boutons BS)
static void btnText(int x, int y, const char *s) { drawText(x + 1, y + 1, s, C_BTN); }

// ------------------------- Rendu du monde ------------------------------
// mur pseudo-3D : face superieure claire + facade foncee + contour
static void drawWall(int sx, int sy, int wave) {
  int lift = 3;
  fRect(sx, sy + lift, TILE, TILE - lift, C_WALLD);
  fRect(sx + 1, sy + 1 + lift, TILE - 2, TILE - 3 - lift, C_WALL);
  fRect(sx + 2, sy + 2 + lift, TILE - 5, 3, C_WALLL);
  fRect(sx, sy, TILE, lift, C_WALLL);
  fRect(sx, sy, TILE, 1, C_BLK); fRect(sx, sy + TILE - 1, TILE, 1, C_BLK);
  fRect(sx, sy, 1, TILE, C_BLK); fRect(sx + TILE - 1, sy, 1, TILE, C_BLK);
  // petites fissures / texture
  px(sx + 4, sy + lift + 5, C_WALLD); px(sx + 9, sy + lift + 8, C_WALLD);
  px(sx + 7, sy + lift + 6, C_WALLD); (void)wave;
}
// buisson BS : blobs verts arrondis
static void drawBush(int sx, int sy) {
  fRect(sx, sy, TILE, TILE, C_BUSH);
  fCirc(sx + 4, sy + 4, 4, C_BUSH2);
  fCirc(sx + 10, sy + 5, 4, C_BUSH2);
  fCirc(sx + 7, sy + 10, 4, C_BUSH2);
  fCirc(sx + 3, sy + 9, 3, C_BUSH);
  px(sx + 5, sy + 3, C_GRD3); px(sx + 11, sy + 4, C_GRD3); px(sx + 8, sy + 9, C_GRD3);
}
// gemme diamant BS (losange cyan avec reflet)
static void drawGem(int cx, int cy, int t) {
  int bob = (t / 400) % 2;
  shadow(cx, cy + 5, 4, 2);
  for (int j = -5; j <= 5; j++)
    for (int i = -4; i <= 4; i++) {
      int w = (j < 0) ? 4 + j : 4 - j;
      if (abs(i) <= w) px(cx + i, cy + j - bob, (i < -1 || j < -2) ? C_GEMD : C_GEM);
    }
  px(cx - 1, cy - 3, C_WHT); px(cx, cy - 4, C_WHT);
}
// ballon avec ombre + bande noire
static void drawBall(int cx, int cy) {
  shadow(cx, cy + 6, 5, 2);
  oCirc(cx, cy, 5, C_BALL, C_BLK);
  fRect(cx - 5, cy - 1, 10, 2, C_BLK);
  px(cx - 2, cy - 3, C_WHT);
}

// barre de vie BS : segmentee, avec fond noir et segments de 400 PV
static void drawHPBar(int sx, int sy, float hp, float maxHP, KDColor col, KDColor colD) {
  int w = 18;
  fRect(sx - w / 2 - 1, sy - 1, w + 2, 6, C_BLK);
  fRect(sx - w / 2, sy, w, 4, KDColor::RGB24(0x3A3A3A));
  int fill = (int)(w * hp / maxHP);
  fRect(sx - w / 2, sy, fill, 4, col);
  fRect(sx - w / 2, sy + 3, fill, 1, colD); // bas fonce => volume
  for (int s = 4; s < w; s += 4) fRect(sx - w / 2 + s, sy, 1, 4, C_BLK); // separateurs
  // dernier segment charge = PV en trop (surcharge), style BS
}

// dessin d'un brawler : ombre + corps degrade + equipement + animation marche
static void drawEnt(Ent &e, int sx, int sy, bool mine, bool isAlly) {
  const BrawlerDef &d = BRAWLERS[e.brawlerIdx];
  bool teamRed = (mode == MODE_SOLO) ? !e.isHuman : (e.team != ents[humanIdx].team);
  KDColor tCol = teamRed ? C_RED : C_BLUE;
  KDColor tColD = teamRed ? C_REDD : C_BLUED;
  bool flash = e.lastHitT > 0 && (e.lastHitT / 50) % 2 == 0;

  // ombre au sol
  shadow(sx, sy + 7, 7, 3);
  // trainee hypercharge
  if (e.hyperT > 0) { fRing(sx, sy, 12, C_MAG); fRing(sx, sy, 13 + (animT / 80) % 2, C_PUR); }
  // animation de marche : petit rebond
  int bob = ((e.walkT / 40) % 2) * (e.dashT > 0 ? 2 : 1);
  int by = sy - bob;

  // corps degrade + contour cartoon
  KDColor top = flash ? C_WHT : KDColor::RGB24(d.colTop);
  KDColor bot = flash ? C_GRE : KDColor::RGB24(d.colBot);
  shCirc(sx, by, 7, top, bot, C_BLK);
  // visage : yeux vers la direction regardee
  int ex = (int)(cosf(e.faceAng) * 3), ey = (int)(sinf(e.faceAng) * 2);
  fRect(sx + ex - 3, by + ey - 2, 2, 3, C_BLK);
  fRect(sx + ex + 1, by + ey - 2, 2, 3, C_BLK);
  // bandeau d'equipe (couleur bleu/rouge autour de la tete, comme BS)
  arc(sx, by, 8, 3.34f, 6.08f, 2, tCol);
  // arme pointant dans la direction de visee
  int gx = (int)(cosf(e.aimAng) * 9), gy = (int)(sinf(e.aimAng) * 9);
  fCirc(sx + gx, by + gy, 2, C_GRE);
  // munitions sous le joueur (barres orange, style BS)
  for (int a = 0; a < 3; a++) {
    int filled = (int)(fmaxf(0, fminf(1, e.ammo - a)) * 4);
    fRect(sx - 8 + a * 6, by + 9, 5, 2, C_BLK);
    fRect(sx - 8 + a * 6, by + 9, filled, 2, C_ORG);
  }
  // anneau de super charge (violet, pulse quand plein)
  if (e.superCharge >= 100) {
    int r = 10 + (animT / 150) % 2;
    fRing(sx, by, r, C_PUR);
    fCirc(sx + (int)(cosf(animT * 0.01f) * r), by + (int)(sinf(animT * 0.01f) * r), 1, C_YEL);
  } else if (e.superCharge > 0) {
    arc(sx, by, 10, -1.5708f, -1.5708f + 6.2832f * e.superCharge / 100.0f, 2, C_PUR);
  }
  // barre de vie au-dessus
  drawHPBar(sx, by - 15, e.hp, e.maxHP, e.isHuman ? C_GREEN : (isAlly ? C_BLUE : C_RED), tColD);
  // compteur de gemmes porte (badge vert BS)
  if (e.gems > 0) {
    fCirc(sx + 12, by - 12, 6, C_GREEN);
    fCirc(sx + 12, by - 12, 6, C_BLK == C_BLK ? C_GREEN : C_GREEN);
    fCirc(sx + 12, by - 12, 5, C_GREEN);
    fCirc(sx + 12, by - 12, 6, C_GREEN);
    drawNum(sx + 9, by - 14, e.gems, C_WHT);
  }
  // ballon porte au-dessus de la tete
  if (e.hasBall) { oCirc(sx, by - 22, 4, C_BALL, C_BLK); }
}

// projectile selon sa forme
static void drawProj(Proj &p, int sx, int sy) {
  KDColor c = p.fromSuper ? C_PUR : (p.team == (mode == MODE_SOLO ? ents[humanIdx].team : ents[humanIdx].team) ? C_YEL : C_RED);
  KDColor c2 = p.fromSuper ? C_MAG : C_ORG;
  switch (p.shape) {
    case 0: oCirc(sx, sy, p.radius + 1, c, C_BLK); break;
    case 1: // eclat allonge dans le sens du deplacement
      for (int t = -2; t <= 2; t++)
        px(sx + (int)(p.vx * t * 0.008f), sy + (int)(p.vy * t * 0.008f), t < 0 ? c : c2);
      break;
    case 2: // fusee avec flamme
      oCirc(sx, sy, p.radius + 1, c, C_BLK);
      px(sx - (int)(p.vx * 0.02f), sy - (int)(p.vy * 0.02f), C_ORG);
      px(sx - (int)(p.vx * 0.03f), sy - (int)(p.vy * 0.03f), C_YEL);
      break;
    default: // grenade qui tournoie
      fCirc(sx, sy, p.radius + 1, c);
      px(sx + (p.spin / 8) % 3 - 1, sy - (p.spin / 16) % 2, C_BLK);
      break;
  }
}

static void renderMatch() {
  Ent &me = ents[humanIdx];
  int camX = (int)me.x - SW / 2, camY = (int)me.y - SH / 2;
  camX = fmaxf(0, fminf(MAPW * TILE - SW, camX));
  camY = fmaxf(0, fminf(MAPH * TILE - SH, camY));
  if (shakeT > 0) { camX += rnd(shakeMag * 2) - shakeMag; camY += rnd(shakeMag * 2) - shakeMag; }

  // sol en damier BS avec brins d'herbe
  for (int ty = camY / TILE; ty <= (camY + SH) / TILE && ty < MAPH; ty++)
    for (int tx = camX / TILE; tx <= (camX + SW) / TILE && tx < MAPW; tx++) {
      KDColor c = ((tx + ty) & 1) ? C_GRD2 : C_GRD;
      fRect(tx * TILE - camX, ty * TILE - camY, TILE, TILE, c);
      // brins d'herbe decoratifs deterministes
      if (((tx * 7 + ty * 13) & 7) == 0) {
        int bx = tx * TILE - camX + (tx * 5 + ty * 3) % 10;
        int by = ty * TILE - camY + (tx * 3 + ty * 7) % 10;
        px(bx, by, C_GRD3); px(bx, by - 1, C_GRD3); px(bx + 1, by, C_GRD3);
      }
      if (tileMap[tx][ty] == 1) drawWall(tx * TILE - camX, ty * TILE - camY, animT);
      else if (tileMap[tx][ty] == 2) drawBush(tx * TILE - camX, ty * TILE - camY);
    }

  // cages de but (Brawl Ball)
  if (mode == MODE_BALL) {
    for (int ty = MAPH / 2 - 2; ty <= MAPH / 2 + 2; ty++) {
      fRect(0 - camX + 2, ty * TILE - camY + 2, TILE - 4, TILE - 4, C_BLUED);   // but bleu (gauche)
      fRect(MAPW * TILE - TILE - camX + 2, ty * TILE - camY + 2, TILE - 4, TILE - 4, C_REDD); // but rouge (droite)
    }
  }

  // zone empoisonnee (Survivant) : bord violet anime + assombrissement exterieur
  if (mode == MODE_SOLO) {
    int cx = MAPW * TILE / 2 - camX, cy = MAPH * TILE / 2 - camY;
    for (int a = 0; a < 360; a += 6) {
      int ex = cx + (int)(soloShrink * cosf(a * 0.01745f));
      int ey = cy + (int)(soloShrink * sinf(a * 0.01745f));
      fRect(ex - 2, ey - 2, 5, 5, C_POISON);
      if ((a / 6 + animT / 200) % 4 == 0) fRect(ex - 3, ey - 3, 7, 7, C_POIS2);
    }
  }

  // gemmes et ballon
  if (mode == MODE_GEM)
    for (int g = 0; g < 10; g++)
      if (gems[g].active) drawGem((int)gems[g].x - camX, (int)gems[g].y - camY, animT + g * 300);
  if (mode == MODE_BALL) drawBall((int)ballX - camX, (int)ballY - camY);

  // entites (tri par Y pour superposition correcte)
  for (int pass = 0; pass < entCount; pass++) {
    int best = -1, bestY = 1 << 30;
    for (int i = 0; i < entCount; i++) {
      Ent &e = ents[i];
      if (!e.alive || e.drawDone) continue;
      int sy = (int)e.y;
      if (sy < bestY) { bestY = sy; best = i; }
    }
    if (best < 0) break;
    ents[best].drawDone = true;
    Ent &e = ents[best];
    int sx = (int)e.x - camX, sy2 = (int)e.y - camY;
    if (best != humanIdx && inBush(e.x, e.y)) {
      float dx = e.x - me.x, dy = e.y - me.y;
      if (dx * dx + dy * dy > 60 * 60) continue;
    }
    drawEnt(e, sx, sy2, best == humanIdx, e.team == me.team);
  }
  for (int i = 0; i < entCount; i++) ents[i].drawDone = false;

  // projectiles + impacts
  for (int i = 0; i < MAX_PROJ; i++)
    if (projs[i].active) {
      shadow((int)projs[i].x - camX, (int)projs[i].y - camY + 6, 2, 1);
      drawProj(projs[i], (int)projs[i].x - camX, (int)projs[i].y - camY);
    }

  // degats flottants
  for (int i = 0; i < MAX_POP; i++)
    if (pops[i].active)
      drawNum((int)pops[i].x - camX - 6, (int)pops[i].y - camY, pops[i].val,
              pops[i].big ? C_YEL : (pops[i].val > 0 ? C_WHT : C_RED));

  // ---- HUD style BS ----
  // bandeau haut
  fRect(0, 0, SW, 24, C_PANEL);
  fRect(0, 22, SW, 2, C_PANEL2);
  // portrait joueur (mini-face)
  const BrawlerDef &d = BRAWLERS[me.brawlerIdx];
  oCirc(16, 12, 9, KDColor::RGB24(d.colTop), C_WHT);
  fRect(11, 9, 3, 4, C_BLK); fRect(18, 9, 3, 4, C_BLK);
  drawText(30, 5, d.name, C_WHT);
  int lvl = (me.accIdx >= 0) ? acc.b[me.accIdx].level : 1;
  // badge de niveau (pastille jaune BS)
  fRect(30 + textW(d.name) + 2, 3, 14, 12, C_YEL);
  fRect(30 + textW(d.name) + 2, 12, 14, 3, C_BTND);
  drawNum(34 + textW(d.name), 5, lvl, C_BLK);

  // gadget (pastille cyan BS)
  fRect(150, 3, 18, 18, me.gadgetUses > 0 ? C_CYN : KDColor::RGB24(0x225566));
  drawText(155, 7, "X", C_BLK);
  drawNum(156, 7, me.gadgetUses, C_WHT);
  // hypercharge (pastille magenta si debloquee)
  if (me.accIdx >= 0 && acc.b[me.accIdx].hyper) {
    fRect(172, 3, 24, 18, me.hyperT > 0 ? C_MAG : KDColor::RGB24(0x66114A));
    drawText(175, 8, "HYP", C_WHT);
  }
  // temps restant (grand, centre)
  drawNum(210, 8, fmaxf(0, 150 - matchTimeMs / 1000), C_WHT);

  // score au centre haut, style BS
  if (mode == MODE_GEM) {
    fRect(240, 3, 76, 18, C_BLK);
    drawNum(250, 8, teamGems[0], C_BLUE);
    drawGem(270, 12, animT);
    drawNum(295, 8, teamGems[1], C_RED);
    if (gemCountdown > 0) drawNum(226, 8, gemCountdown / 1000, C_YEL);
  } else if (mode == MODE_BALL) {
    int g0 = 0, g1 = 0;
    for (int i = 0; i < entCount; i++)
      if (ents[i].team == 0) g0 = fmaxf(g0, ents[i].goals);
      else g1 = fmaxf(g1, ents[i].goals);
    fRect(240, 3, 76, 18, C_BLK);
    drawNum(255, 8, g0, C_BLUE); drawBall(278, 12); drawNum(300, 8, g1, C_RED);
  } else {
    int na = 0;
    for (int i = 0; i < entCount; i++) if (ents[i].alive) na++;
    fRect(240, 3, 76, 18, C_BLK);
    drawText(246, 8, "VIVANTS", C_WHT); drawNum(300, 8, na, C_YEL);
  }

  // message respawn avec compte a rebours (style BS)
  if (!me.alive) {
    fRect(SW / 2 - 90, 90, 180, 40, C_BLK);
    fRect(SW / 2 - 88, 92, 176, 36, C_PANEL);
    drawTextC(96, "REAPPARITION", C_WHT);
    drawNum(SW / 2 - 4, 110, (me.respawnT + 999) / 1000, C_YEL);
  }

  // rappel touches discret en bas
  fRect(0, SH - 12, SW, 12, KDColor::RGB24(0x111827));
  drawText(4, SH - 10, "OK ATTAQUE  SHIFT SUPER  X GADGET  - HYP", C_GRE);

  blit();
}

// ------------------------- Menus style BS ------------------------------
static int menuPick(const char *title, const char **items, int n, int start) {
  int sel = start;
  while (true) {
    // fond violet BS avec rayons decoratifs
    for (int y = 0; y < SH; y++)
      for (int x = 0; x < SW; x++) {
        KDColor c = (((x + y * 2) / 40) % 2) ? C_PANEL : C_PANEL2;
        px(x, y, c);
      }
    // logo : ecran de jeu miniature + titre jaune contourne
    drawTextC(8, title, C_YEL);
    fRect(SW / 2 - 60, 22, 120, 3, C_BTND);
    for (int i = 0; i < n; i++) {
      int y = 36 + i * 20;
      // bouton jaune arrondi BS
      rRect(30, y, SW - 60, 16, 6, i == sel ? C_YEL : KDColor::RGB24(0x5A4A9A));
      if (i == sel) { rRect(30, y + 2, SW - 60, 14, 6, C_BTN); }
      drawText(40, y + 5, items[i], i == sel ? C_BLK : C_WHT);
    }
    drawTextC(SH - 14, "OK CHOISIR   BACK RETOUR", C_GRE);
    blit();
    pollKeys();
    if (kUp && sel > 0) sel--;
    if (kDown && sel < n - 1) sel++;
    if (keyOK && !prevOK) { prevOK = true; return sel; }
    if (keyBack && !prevBack) { prevBack = true; return -1; }
    prevOK = keyOK; prevBack = keyBack;
    Ion::Timing::msleep(60);
  }
}

// carte brawler : portrait + badges + stats + boutons d'achat
static void brawlerMenu(int myBrawler) {
  while (true) {
    const char *names[15];
    for (int i = 0; i < 15; i++) names[i] = BRAWLERS[i].name;
    int sel = menuPick("CHOISIS TON BRAWLER", names, 15, myBrawler);
    if (sel < 0) return;
    myBrawler = sel;
    while (true) {
      const BrawlerDef &d = BRAWLERS[sel];
      BrawlerAccount &a = acc.b[sel];
      float mul = lvlMul(a.level);
      for (int y = 0; y < SH; y++)
        for (int x = 0; x < SW; x++)
          px(x, y, (((x + y * 2) / 40) % 2) ? C_PANEL : C_PANEL2);

      // grand portrait anime (bouche + rebond)
      int bob = (animT / 400) % 2;
      oCirc(50, 60 - bob, 22, KDColor::RGB24(d.colTop), C_WHT);
      shCirc(50, 60 - bob, 22, KDColor::RGB24(d.colTop), KDColor::RGB24(d.colBot), C_WHT);
      fRect(40, 52 - bob, 5, 7, C_BLK); fRect(55, 52 - bob, 5, 7, C_BLK);
      fRect(44, 66 - bob, 12, 3, C_BLK); // sourire
      shadow(50, 88, 16, 4);
      // badge niveau sur le portrait (pastille jaune BS)
      fRect(64, 40, 22, 16, C_YEL); fRect(64, 51, 22, 5, C_BTND);
      drawNum(70, 43, a.level, C_BLK);

      drawText(90, 30, d.name, C_YEL);
      // trophees (icone coupe)
      fRect(230, 28, 8, 4, C_TROPH); fRect(231, 32, 6, 2, C_TROPH); fRect(233, 34, 2, 4, C_TROPH);
      drawNum(245, 30, a.trophies, C_WHT);
      // pieces (icone piece)
      oCirc(230, 50, 4, C_YEL, C_BTND); drawNum(245, 46, acc.coins, C_WHT);

      // stats en cartes style BS
      rRect(10, 100, 90, 26, 5, KDColor::RGB24(0x2B3A55));
      drawText(16, 104, "PV", C_WHT);
      drawNum(16, 112, (int)(d.baseHP * mul * ((a.starPower && d.star == STAR_HP) ? 1.05f : 1)), C_GREEN);
      rRect(110, 100, 90, 26, 5, KDColor::RGB24(0x2B3A55));
      drawText(116, 104, "DEGATS", C_WHT);
      drawNum(116, 112, (int)(d.baseDmg * mul * ((a.starPower && d.star == STAR_DMG) ? 1.1f : 1)), C_ORG);
      rRect(210, 100, 100, 26, 5, KDColor::RGB24(0x2B3A55));
      drawText(216, 104, "PORTEE", C_WHT);
      drawNum(216, 112, d.range, C_CYN);

      // badges gadget / star / hyper (ronds colornes BS)
      rRect(10, 134, 96, 26, 5, a.gadget ? C_CYN : KDColor::RGB24(0x225566));
      drawText(16, 140, "GADGET", a.gadget ? C_BLK : C_GRE);
      drawText(16, 148, a.gadget ? "OUI" : "NON", a.gadget ? C_BLK : C_GRE);
      rRect(112, 134, 96, 26, 5, a.starPower ? C_PUR : KDColor::RGB24(0x3A1F55));
      drawText(118, 140, "POUV. STAR", a.starPower ? C_WHT : C_GRE);
      drawText(118, 148, a.starPower ? "OUI" : "NON", a.starPower ? C_WHT : C_GRE);
      rRect(214, 134, 96, 26, 5, a.hyper ? C_MAG : KDColor::RGB24(0x55114A));
      drawText(220, 140, "HYPERCH.", a.hyper ? C_WHT : C_GRE);
      drawText(220, 148, a.hyper ? "OUI" : (a.level >= 11 ? "DISPO" : "NIV 11"), a.hyper ? C_WHT : C_GRE);

      // ligne d'achats
      int cost = upgradeCost(a.level);
      if (a.level < 11) {
        rRect(10, 168, 140, 24, 5, (acc.coins >= cost) ? C_YEL : KDColor::RGB24(0x5A4A9A));
        drawText(16, 175, "+ NIV SUIVANT", C_BLK); drawNum(110, 175, cost, C_BLK);
      } else {
        rRect(10, 168, 140, 24, 5, C_GREEN);
        drawText(16, 175, "NIVEAU MAX!", C_BLK);
      }
      if (!a.gadget) { rRect(156, 168, 74, 24, 5, (acc.coins >= 100) ? C_CYN : KDColor::RGB24(0x225566)); drawText(162, 175, "* GADGET", C_BLK); drawNum(202, 175, 100, C_BLK); }
      if (!a.starPower) { rRect(156, 196, 74, 22, 5, (a.level >= 3 && acc.coins >= 150) ? C_PUR : KDColor::RGB24(0x3A1F55)); drawText(162, 202, "/ STAR", C_WHT); drawNum(202, 202, 150, C_WHT); }
      if (a.level >= 11 && !a.hyper) { rRect(234, 196, 76, 22, 5, (acc.coins >= 300) ? C_MAG : KDColor::RGB24(0x55114A)); drawText(240, 202, "^ HYP", C_WHT); drawNum(272, 202, 300, C_WHT); }

      drawText(240, 175, "OK RETOUR", C_GRE);
      blit();
      pollKeys();
      animT += 80;
      if (a.level < 11 && acc.coins >= cost && (Ion::Keyboard::getState().keyDown(Ion::Keyboard::Key::Plus))) {
        acc.coins -= cost; a.level++;
      }
      if (!a.gadget && acc.coins >= 100 && (Ion::Keyboard::getState().keyDown(Ion::Keyboard::Key::Multiply))) {
        acc.coins -= 100; a.gadget = true;
      }
      if (a.level >= 3 && !a.starPower && acc.coins >= 150 && (Ion::Keyboard::getState().keyDown(Ion::Keyboard::Key::Division))) {
        acc.coins -= 150; a.starPower = true;
      }
      if (a.level >= 11 && !a.hyper && acc.coins >= 300 && (Ion::Keyboard::getState().keyDown(Ion::Keyboard::Key::Power))) {
        acc.coins -= 300; a.hyper = true;
      }
      if (keyOK || keyBack) { prevOK = keyOK; prevBack = keyBack; break; }
      prevOK = keyOK; prevBack = keyBack;
      Ion::Timing::msleep(80);
    }
  }
}

// ------------------------- Resultat ------------------------------------
static void resultScreen(int result, int myBrawler) {
  int coins = 0, troph = 0;
  if (result == 1) { coins = 60 + rnd(40); troph = 8; }
  else if (result == 0) { coins = 25 + rnd(15); troph = -2; }
  else { coins = 10 + rnd(10); troph = 0; }
  acc.coins += coins;
  acc.b[myBrawler].trophies += troph;
  if (acc.b[myBrawler].trophies < 0) acc.b[myBrawler].trophies = 0;

  const char *msg = (result == 1) ? "VICTOIRE!" : (result == 0) ? "EGALITE" : "DEFAITE";
  KDColor col = (result == 1) ? C_YEL : (result == 0) ? C_WHT : C_RED;
  while (true) {
    for (int y = 0; y < SH; y++)
      for (int x = 0; x < SW; x++)
        px(x, y, (((x + y * 2) / 40) % 2) ? C_PANEL : C_PANEL2);
    // banniere resultat
    rRect(SW / 2 - 100, 40, 200, 50, 10, col);
    drawTextC(60, msg, C_BLK);
    drawTextC(66, "RECOMPENSES", C_WHT);
    // piece + trophee
    oCirc(SW / 2 - 40, 120, 8, C_YEL, C_BTND);
    drawText(SW / 2 - 60, 115, "+", C_WHT);
    drawNum(SW / 2 - 24, 116, coins, C_WHT);
    fRect(SW / 2 + 20, 112, 10, 5, C_TROPH); fRect(SW / 2 + 22, 117, 6, 2, C_TROPH); fRect(SW / 2 + 24, 119, 2, 5, C_TROPH);
    drawNum(SW / 2 + 36, 116, troph, troph >= 0 ? C_YEL : C_RED);
    rRect(SW / 2 - 70, 170, 140, 24, 8, C_YEL);
    drawTextC(176, "OK CONTINUER", C_BLK);
    blit();
    pollKeys();
    if (keyOK && !prevOK) { prevOK = true; return; }
    prevOK = keyOK;
    Ion::Timing::msleep(80);
  }
}

// ------------------------- Boucle de jeu -------------------------------
static void playMatch(int myBrawler, int selMode) {
  setupMatch(selMode, myBrawler);
  prevOK = prevShift = prevX = prevMinus = prevBack = false; keyBack = false; matchResult = -2;
  while (matchResult == -2) {
    int t0 = (int)Ion::Timing::millis();
    updateMatch(1.0f / 30.0f);
    renderMatch();
    int frameMs = (int)Ion::Timing::millis() - t0;
    Ion::Timing::msleep(frameMs < 33 ? 33 - frameMs : 1);
  }
  resultScreen(matchResult, myBrawler);
}

// ------------------------- Point d'entree ------------------------------
void ion_main(int argc, char *argv[]) {
  (void)argc; (void)argv;
  initAcc();
  int myBrawler = 0;
  const char *mainItems[4] = {"JOUER", "BRAWLERS", "MODE DE JEU", "AIDE"};
  const char *modes[3] = {"RAMASSE-GEMMES  3V3", "BRAWL BALL  3V3", "SURVIVANT  6 JOUEURS"};
  while (true) {
    int choice = menuPick("BRAWL MICROSTARS", mainItems, 4, 0);
    if (choice < 0) return;
    if (choice == 0) {
      int selMode = menuPick("MODE DE JEU", modes, 3, 0);
      if (selMode < 0) continue;
      playMatch(myBrawler, selMode);
    } else if (choice == 1) {
      brawlerMenu(myBrawler);
    } else if (choice == 2) {
      int selMode = menuPick("MODE DE JEU", modes, 3, 0);
    } else {
      for (int y = 0; y < SH; y++)
        for (int x = 0; x < SW; x++)
          px(x, y, (((x + y * 2) / 40) % 2) ? C_PANEL : C_PANEL2);
      drawTextC(8, "AIDE", C_YEL);
      fRect(SW / 2 - 60, 22, 120, 3, C_BTND);
      const char *lines[7] = {
        "FLECHES: BOUGER", "OK: ATTAQUER (AUTO-VISEE)",
        "SHIFT: SUPER", "X: GADGET", "-: HYPERCHARGE",
        "+ * / : ACHATS MENU BRAWLERS", "TOUCHE ENNEMIS POUR SUPER"
      };
      for (int i = 0; i < 7; i++) drawTextC(40 + i * 18, lines[i], C_WHT);
      rRect(SW / 2 - 70, 180, 140, 24, 8, C_YEL);
      drawTextC(186, "OK RETOUR", C_BLK);
      blit();
      prevOK = true;
      while (prevOK) { pollKeys(); prevOK = keyOK; Ion::Timing::msleep(60); }
      prevOK = false;
    }
  }
}

extern const char eadk_app_name[] __attribute__((section(".rodata.eadk_app_name"))) = "Mini BS";
extern const uint32_t eadk_api_level __attribute__((section(".rodata.eadk_api_level"))) = 0;
int main(int argc, char *argv[]) {
  ion_main(argc, argv);
  return 0;
}
